/*
    Registrarse e iniciar sesión. -> Hecho en authControlador.
    Armar uno o varios productos paso a paso y confirmarlos en un mismo pedido. 
    Ver el estado y el historial de sus pedidos. 
    Cancelar un pedido mientras siga Pendiente.
*/

import Usuario from "../modelos/Usuario.js";
import mongoose from "mongoose";
import Orden from "../modelos/Orden.js";
import Ingrediente from "../modelos/Ingrediente.js";

const consultarHistorial = async (req, res) => {
    
    try {
        const ordenes = (await Orden.find({cliente: req.Usuario._id})).sort({createdAt: -1});

        res.status(200).json(ordenes);
    } catch (error) {
        console.log(error);
        res.status(500).json({msg: "Error al recuperar el historial de pedidos."});
    }
}

